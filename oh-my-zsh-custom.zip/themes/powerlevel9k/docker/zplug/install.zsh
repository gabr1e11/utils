#!zsh

curl -sL --proto-redir -all,https https://raw.githubusercontent.com/zplug/installer/master/installer.zsh| zsh

# git clone https://github.com/zplug/zplug "${HOME}/.zplug"
